// Confirm before destructive actions
document.querySelectorAll("form[data-confirm]").forEach(f =>
  f.addEventListener("submit", e => { if (!confirm(f.dataset.confirm)) e.preventDefault(); }));

// Live search for cards
const s = document.querySelector("[data-filter]");
if (s) s.addEventListener("input", () => {
  const t = s.value.toLowerCase();
  document.querySelectorAll(s.dataset.filter).forEach(c => c.style.display = c.textContent.toLowerCase().includes(t) ? "" : "none");
});

// Checklists saved in this browser
document.querySelectorAll(".checklist").forEach(box => {
  const key = box.dataset.key, boxes = [...box.querySelectorAll("input")];
  let saved = [];
  try { saved = JSON.parse(localStorage.getItem(key)) || []; } catch (e) {}
  boxes.forEach((b, i) => b.checked = saved.includes(i));
  const update = () => {
    const done = boxes.map((b, i) => b.checked ? i : -1).filter(i => i >= 0);
    try { localStorage.setItem(key, JSON.stringify(done)); } catch (e) {}
    box.querySelector(".bar i").style.width = (done.length * 100 / boxes.length) + "%";
    box.querySelector(".progress").textContent = done.length + " of " + boxes.length + " done";
  };
  boxes.forEach(b => b.addEventListener("change", update));
  box.querySelector(".reset").addEventListener("click", () => { boxes.forEach(b => b.checked = false); update(); });
  update();
});
